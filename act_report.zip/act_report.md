﻿**WeRateDogs Twitter**  

**Data Act Report :-**  

**Research Questions:** 

1. Does the dog having a name or stage have anything to do with them having high rates? 

We started this by observing the difference between mean of rates of dogs having either a name or a stage and those who don’t have both, we observed the difference in mean between those respectively is 0.85 

Our hypothesis is as follow :-  

![](act\_report.001.png)

![](act\_report.002.png)

Under assumption that null hypothesis is true , the position of the observed difference under the null distribution is illustrated in Figure 1 

With a corresponding **P-value =**  **0**, which means that we reject the null, and dogs with either names or stages have higher rates than those without both.  

![](act\_report.003.png)

`                                                                                `Figure 1 

2. Are there any common names for dogs ? 

As we see in Figure 2:- The most common name for dogs is charlie.  

![](act\_report.004.png)

And here’s a photo with the highest ranked good boy Charlie ( with respect to Rate, Favorite Count and Retweets Count)  

![](act\_report.005.png)

3. What are the most common words WeRateDogs say? 

![](act\_report.006.png)

As we can see in the above Figure , the most common words said by WeRateDogs , We can say  that they curse a lot .  

4. Does Posting Time have anything to do with higher rates? ![](act\_report.007.png)

(Rate on y-axis, Hour of posting on x-axis, Favorite Count + Retweet counts is the size of point)  

We can see from the above plot two things  

1. There is no activity between 6 AM and 12PM  
1. Tweets including higher rates is retweeted and favorited more 
5. Does any dog stage have more rates than the others?

![](act\_report.008.png)

We can see from the above plots that puppos are rated slightly more than the others 

6. TOP 5 retweeted and favorited tweets? 

![](act\_report.009.png)
